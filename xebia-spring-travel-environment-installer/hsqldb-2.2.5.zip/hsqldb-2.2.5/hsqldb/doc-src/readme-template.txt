Readme File
$Date: 2009-03-16 13:05:36 -0400 (Mon, 16 Mar 2009) $
This package contains HyperSQL v. ${hsqldb.version}

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
